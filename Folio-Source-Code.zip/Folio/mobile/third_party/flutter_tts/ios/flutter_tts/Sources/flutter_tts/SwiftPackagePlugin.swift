#if SWIFT_PACKAGE
public typealias FlutterTtsPlugin = SwiftFlutterTtsPlugin
#endif
