#if SWIFT_PACKAGE
public typealias FlutterSecureStoragePlugin = SwiftFlutterSecureStoragePlugin
#endif
