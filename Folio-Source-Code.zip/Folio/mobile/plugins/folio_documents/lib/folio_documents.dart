/// Native implementation of Folio's `folio/documents` method channel.
///
/// Registered automatically by Flutter and xcross on iOS. The application
/// calls the channel through its existing DocumentScanner service.
library;
